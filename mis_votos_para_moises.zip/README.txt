# Mis votos hacia ti — página para Moisés

La página está lista para publicarse. Abre `index.html` para verla localmente.

## Para convertirla en un enlace público
Sube la carpeta completa a un servicio de hosting de páginas estáticas. Es importante subir también la carpeta `assets`, porque ahí están la foto y el video.

Después de tener la URL pública, esa URL se puede convertir en un código QR para imprimir o mandar a Moisés.

## Archivos
- index.html — la página
- assets/portada.jpeg — foto de portada
- assets/nuestro-video.mp4 — video
